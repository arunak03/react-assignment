 
 
import { Component } from "react";
import axios from "axios";
import "./styles.css"


 
class App extends Component{
    state = {
        users:[]
       
    }
   
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=2")
        .then(res => this.setState({users:res.data.data}))
        .catch(err => console.log("Error ",err))
    }
    render(){
       return <div>
        <ol>
                    {this.state.users.map((val,idx)=> <li className={idx % 2 === 0 ? "even" : "odd"}
                     key={val.id}><img width="60" src={val.avatar} alt={val.first_name +" "+ val.last_name}></img>{val.first_name +" "+ val.last_name} </li>)}
                   </ol>   
               </div>
    }
}
 
export default App;
 
 
  