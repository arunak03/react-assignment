import React, { Component } from "react";

class FooterComp extends Component {
  render() {
    return (
      <div>
        <footer className="container">
    <p className="float-end"><a href="#">Back to top</a></p>
    <p>© 2017–2023 Company, Inc. · <a href="#">Privacy</a> · <a href="#">Terms</a></p>
  </footer>
        
      </div>
    );
  }
}

export default FooterComp;