
import {createRoot} from "react-dom/client";
import AppComp from "./components/AppComp";

 createRoot(document.getElementById("root")).render(<AppComp/>)

